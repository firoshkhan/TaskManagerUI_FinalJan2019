import { Component, OnInit } from '@angular/core';
import { Task } from '../../models/task';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
Item:Task;
title = 'Add Task';
id_currency: string = "";
  constructor() {
    this.Item=new Task();
  
  }
  ngOnInit() {
    
  }

  Add() 
  {
    // ssdssf
  }

}
