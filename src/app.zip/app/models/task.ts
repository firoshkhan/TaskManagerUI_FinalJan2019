export class Task {
    Task: string;
    Priority:number;
    ParentTask:string;
    Startdate:Date;
    EndDate:Date;

}
